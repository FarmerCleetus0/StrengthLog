import type { Config } from "@netlify/functions";
import Anthropic from "@anthropic-ai/sdk";
import { getStore } from "@netlify/blobs";
import { and, asc, desc, eq, gte, lte, or, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { meals, savedLabels } from "../../db/schema.js";

const anthropic = new Anthropic();
const MODEL = "claude-sonnet-5-5";
const MAX_IMAGE_BYTES = 4_000_000;
const MAX_IMAGES = 4;

const photos = () => getStore("meal-photos");

const json = (data: unknown, status = 200) => Response.json(data, { status });
const bad = (msg: string, status = 400) => json({ error: msg }, status);

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const num = (v: unknown, max = 100000) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? Math.min(n, max) : 0;
};
const round1 = (n: number) => Math.round(n * 10) / 10;

function parseDataUrl(dataUrl: unknown) {
  if (typeof dataUrl !== "string") return null;
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) return null;
  const bytes = Math.floor((m[2].length * 3) / 4);
  if (bytes > MAX_IMAGE_BYTES) return null;
  return { mediaType: m[1] as "image/jpeg" | "image/png" | "image/webp" | "image/gif", data: m[2] };
}

const MACRO_TOOL: Anthropic.Tool = {
  name: "report_macros",
  description: "Report the estimated nutrition for the food shown or described.",
  input_schema: {
    type: "object",
    properties: {
      is_food: { type: "boolean", description: "False if the image contains no food, drink or nutrition label." },
      kind: { type: "string", enum: ["meal", "label"], description: "'label' if the image is a nutrition facts label / packaging, otherwise 'meal'." },
      name: { type: "string", description: "Short, friendly name for the meal, e.g. 'Chicken burrito bowl' (max 40 chars)." },
      items: {
        type: "array",
        description: "Each distinct food component with estimated portion and macros. For a label, a single item for one serving.",
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            amount: { type: "string", description: "Estimated portion, e.g. '150 g' or '1 cup'." },
            kcal: { type: "number" },
            protein: { type: "number" },
            carbs: { type: "number" },
            fat: { type: "number" },
          },
          required: ["name", "kcal", "protein", "carbs", "fat"],
        },
      },
      kcal: { type: "number", description: "Total calories (for a label: per one serving)." },
      protein: { type: "number", description: "Total protein in grams." },
      carbs: { type: "number", description: "Total carbohydrates in grams." },
      fat: { type: "number", description: "Total fat in grams." },
      fiber: { type: "number", description: "Total fiber in grams, if known." },
      serving: { type: "string", description: "For labels: the serving size printed, e.g. '2/3 cup (55g)'." },
      confidence: { type: "string", enum: ["low", "medium", "high"] },
      tip: { type: "string", description: "One short sentence about assumptions made (portion size, hidden oils, etc.)." },
    },
    required: ["is_food", "kind", "name", "items", "kcal", "protein", "carbs", "fat", "confidence"],
  },
};

function imageList(body: any) {
  const raw = Array.isArray(body?.images) ? body.images : body?.image ? [body.image] : [];
  if (raw.length > MAX_IMAGES) return null;
  const out = raw.map(parseDataUrl);
  return out.every(Boolean) ? (out as NonNullable<ReturnType<typeof parseDataUrl>>[]) : null;
}

const SYSTEM = `You are a sports nutritionist estimating macronutrients for a fitness tracking app.
- For a photo of a meal: identify each component, estimate realistic portion sizes from visual cues (plate size, utensils, hands), include likely cooking oils, sauces and dressings, then sum the totals.
- For a nutrition facts label or packaging: read the values exactly as printed for ONE serving and report the serving size. Do not estimate when the numbers are legible.
- If several photos are given they all belong to ONE meal: e.g. different angles of the same plate, several dishes eaten together, or a meal plus the nutrition label of a packaged item in it. Combine them into one total without double counting food that appears in more than one photo. When a legible label covers an item, use the label's numbers for that item. Use kind 'label' only when the photos are just a packaged product and its label.
- If the user adds a note (e.g. "half portion", "no rice", "2 servings"), apply it to the totals.
- Totals must equal the sum of items. Calories should roughly match 4*protein + 4*carbs + 9*fat.
- Always call the report_macros tool.`;

async function analyze(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body) return bad("Invalid request");
  const note = typeof body.note === "string" ? body.note.slice(0, 300).trim() : "";
  const imgs = imageList(body);
  if (!imgs) return bad(`Couldn't read those photos. Use up to ${MAX_IMAGES} JPEG or PNG images.`);
  if (!imgs.length && !note) return bad("Add a photo or describe what you ate.");

  const content: Anthropic.ContentBlockParam[] = [];
  imgs.forEach((img, i) => {
    if (imgs.length > 1) content.push({ type: "text", text: `Photo ${i + 1}:` });
    content.push({ type: "image", source: { type: "base64", media_type: img.mediaType, data: img.data } });
  });
  const what = imgs.length > 1 ? `these ${imgs.length} photos of one meal` : "this food";
  content.push({
    type: "text",
    text: imgs.length
      ? `Estimate the macros for ${what}.${note ? " User note: " + note : ""}`
      : `Estimate the macros for this meal described by the user: ${note}`,
  });

  try {
    const msg = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 1500,
      system: SYSTEM,
      tools: [MACRO_TOOL],
      tool_choice: { type: "auto" },
      messages: [{ role: "user", content }],
    });
    const tool = msg.content.find((b) => b.type === "tool_use") as Anthropic.ToolUseBlock | undefined;
    if (!tool) return bad("Couldn't estimate this one. Try another photo.", 502);
    const r = tool.input as Record<string, any>;
    if (r.is_food === false) return bad("No food or nutrition label found in that photo.", 422);
    const items = Array.isArray(r.items)
      ? r.items.slice(0, 20).map((i: any) => ({
          name: String(i.name ?? "").slice(0, 60),
          amount: i.amount ? String(i.amount).slice(0, 40) : undefined,
          kcal: Math.round(num(i.kcal)),
          protein: round1(num(i.protein)),
          carbs: round1(num(i.carbs)),
          fat: round1(num(i.fat)),
        }))
      : [];
    return json({
      kind: r.kind === "label" ? "label" : "meal",
      name: String(r.name ?? "Meal").slice(0, 60),
      items,
      kcal: Math.round(num(r.kcal)),
      protein: round1(num(r.protein)),
      carbs: round1(num(r.carbs)),
      fat: round1(num(r.fat)),
      fiber: r.fiber != null ? round1(num(r.fiber)) : null,
      serving: r.serving ? String(r.serving).slice(0, 60) : null,
      confidence: ["low", "medium", "high"].includes(r.confidence) ? r.confidence : "medium",
      tip: r.tip ? String(r.tip).slice(0, 200) : null,
    });
  } catch (e: any) {
    console.error("analyze failed", e?.status, e?.message);
    if (e?.status === 429) return bad("The AI is busy right now. Try again in a minute.", 429);
    return bad("Couldn't reach the AI. Try again.", 502);
  }
}

// Photos can be shared between a meal and a saved label, so only delete a blob once nothing points at it.
async function dropPhotoIfUnused(device: string, key: string) {
  const [m] = await db
    .select({ id: meals.id })
    .from(meals)
    .where(and(eq(meals.deviceId, device), or(eq(meals.photoKey, key), sql`${meals.photoKeys} @> ${JSON.stringify([key])}::jsonb`)))
    .limit(1);
  const [l] = await db
    .select({ id: savedLabels.id })
    .from(savedLabels)
    .where(and(eq(savedLabels.deviceId, device), eq(savedLabels.photoKey, key)))
    .limit(1);
  if (!m && !l) await photos().delete(key).catch(() => {});
}

async function rememberLabel(device: string, l: any, photoKey: string | null) {
  const name = String(l.name || "").trim().slice(0, 60);
  if (!name) return;
  const vals = {
    name,
    serving: l.serving ? String(l.serving).slice(0, 60) : null,
    kcal: Math.round(num(l.kcal)),
    protein: round1(num(l.protein)),
    carbs: round1(num(l.carbs)),
    fat: round1(num(l.fat)),
    fiber: l.fiber != null && l.fiber !== "" ? round1(num(l.fiber)) : null,
  };
  const id = Number(l.id);
  const where = Number.isInteger(id) && id > 0
    ? and(eq(savedLabels.deviceId, device), eq(savedLabels.id, id))
    : and(eq(savedLabels.deviceId, device), sql`lower(${savedLabels.name}) = lower(${name})`);
  const [hit] = await db.select().from(savedLabels).where(where).limit(1);
  if (hit) {
    await db
      .update(savedLabels)
      .set({ ...vals, photoKey: photoKey ?? hit.photoKey, uses: hit.uses + 1, usedAt: new Date() })
      .where(eq(savedLabels.id, hit.id));
    if (hit.photoKey && photoKey && hit.photoKey !== photoKey) await dropPhotoIfUnused(device, hit.photoKey);
  } else {
    await db.insert(savedLabels).values({ deviceId: device, ...vals, photoKey });
  }
}

async function labels(req: Request, device: string, idPart?: string) {
  if (!idPart && req.method === "GET") {
    const rows = await db
      .select()
      .from(savedLabels)
      .where(eq(savedLabels.deviceId, device))
      .orderBy(desc(savedLabels.usedAt))
      .limit(200);
    return json(rows.map(({ deviceId, ...r }) => r));
  }
  if (idPart && req.method === "DELETE") {
    const id = Number(idPart);
    if (!Number.isInteger(id)) return bad("Invalid id");
    const [row] = await db
      .delete(savedLabels)
      .where(and(eq(savedLabels.id, id), eq(savedLabels.deviceId, device)))
      .returning();
    if (!row) return bad("Not found", 404);
    if (row.photoKey) await dropPhotoIfUnused(device, row.photoKey);
    return json({ ok: true });
  }
  return bad("Not found", 404);
}

export default async (req: Request) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/meals\/?/, "").split("/").filter(Boolean);

  // Public photo route: keys are unguessable UUIDs.
  if (parts[0] === "photo" && parts[1] && req.method === "GET") {
    const res = await photos().getWithMetadata(parts[1], { type: "arrayBuffer" });
    if (!res) return new Response("Not found", { status: 404 });
    return new Response(res.data, {
      headers: {
        "Content-Type": String(res.metadata?.contentType ?? "image/jpeg"),
        "Cache-Control": "private, max-age=31536000, immutable",
      },
    });
  }

  const device = req.headers.get("x-device-id") ?? "";
  if (!/^[A-Za-z0-9-]{16,64}$/.test(device)) return bad("Missing device id", 401);

  if (parts[0] === "labels") return labels(req, device, parts[1]);

  if (parts[0] === "analyze") {
    if (req.method !== "POST") return bad("Method not allowed", 405);
    return analyze(req);
  }

  if (parts.length === 0 && req.method === "GET") {
    const from = url.searchParams.get("from") ?? url.searchParams.get("day") ?? "";
    const to = url.searchParams.get("to") ?? from;
    if (!DAY_RE.test(from) || !DAY_RE.test(to)) return bad("Invalid day");
    const rows = await db
      .select()
      .from(meals)
      .where(and(eq(meals.deviceId, device), gte(meals.day, from), lte(meals.day, to)))
      .orderBy(asc(meals.eatenAt));
    return json(rows.map(({ deviceId, ...r }) => r));
  }

  if (parts.length === 0 && req.method === "POST") {
    const b = await req.json().catch(() => null);
    if (!b || !DAY_RE.test(b.day)) return bad("Invalid meal");
    const keys: string[] = [];
    for (const img of imageList(b) ?? []) {
      const key = crypto.randomUUID();
      const buf = Buffer.from(img.data, "base64");
      await photos().set(key, buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer, {
        metadata: { contentType: img.mediaType, device },
      });
      keys.push(key);
    }
    // Re-logging a saved label can reuse its stored photo.
    if (!keys.length && typeof b.photoKey === "string" && /^[0-9a-f-]{36}$/.test(b.photoKey)) keys.push(b.photoKey);
    const photoKey = keys[0] ?? null;
    const [row] = await db
      .insert(meals)
      .values({
        deviceId: device,
        day: b.day,
        name: String(b.name || "Meal").slice(0, 60),
        kind: ["meal", "label", "manual"].includes(b.kind) ? b.kind : "meal",
        kcal: Math.round(num(b.kcal)),
        protein: round1(num(b.protein)),
        carbs: round1(num(b.carbs)),
        fat: round1(num(b.fat)),
        fiber: b.fiber != null && b.fiber !== "" ? round1(num(b.fiber)) : null,
        items: Array.isArray(b.items) ? b.items.slice(0, 20) : null,
        note: b.note ? String(b.note).slice(0, 300) : null,
        photoKey,
        photoKeys: keys.length ? keys : null,
      })
      .returning();
    const kind = row.kind;
    if (kind === "label" && b.saveLabel && typeof b.saveLabel === "object") {
      await rememberLabel(device, b.saveLabel, photoKey).catch((e) => console.error("save label failed", e?.message));
    }
    const { deviceId, ...out } = row;
    return json(out, 201);
  }

  if (parts.length === 1 && req.method === "DELETE") {
    const id = Number(parts[0]);
    if (!Number.isInteger(id)) return bad("Invalid id");
    const [row] = await db
      .delete(meals)
      .where(and(eq(meals.id, id), eq(meals.deviceId, device)))
      .returning();
    if (!row) return bad("Not found", 404);
    for (const k of row.photoKeys ?? (row.photoKey ? [row.photoKey] : [])) await dropPhotoIfUnused(device, k);
    return json({ ok: true });
  }

  return bad("Not found", 404);
};

export const config: Config = {
  path: ["/api/meals", "/api/meals/*"],
};
