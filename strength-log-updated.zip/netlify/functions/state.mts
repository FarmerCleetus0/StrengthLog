import type { Config } from "@netlify/functions";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { appState } from "../../db/schema.js";

const MAX_BYTES = 3_000_000;
const json = (data: unknown, status = 200) => Response.json(data, { status });
const bad = (msg: string, status = 400) => json({ error: msg }, status);

const hasData = (d: any) =>
  !!d && ((Array.isArray(d.hist) && d.hist.length > 0) || (Array.isArray(d.routines) && d.routines.length > 0) || !!d.active);

export default async (req: Request) => {
  const device = req.headers.get("x-device-id") ?? "";
  if (!/^[A-Za-z0-9-]{16,64}$/.test(device)) return bad("Missing device id", 401);

  if (req.method === "GET") {
    const [row] = await db.select().from(appState).where(eq(appState.deviceId, device));
    return json(row ? { data: row.data, updatedAt: row.updatedAt } : { data: null });
  }

  if (req.method === "PUT") {
    const text = await req.text();
    if (text.length > MAX_BYTES) return bad("Backup is too large", 413);
    let body: any;
    try {
      body = JSON.parse(text);
    } catch {
      return bad("Invalid JSON");
    }
    const data = body?.data;
    if (!data || typeof data !== "object" || !Array.isArray(data.ex) || !Array.isArray(data.hist)) return bad("Invalid data");

    // Never let an empty, freshly-started app overwrite a backup that has workouts in it
    // unless the user explicitly asked for it.
    if (!body.force && !hasData(data)) {
      const [row] = await db.select().from(appState).where(eq(appState.deviceId, device));
      if (row && hasData(row.data)) return json({ ok: false, conflict: true, data: row.data, updatedAt: row.updatedAt }, 409);
    }

    const now = new Date();
    await db
      .insert(appState)
      .values({ deviceId: device, data, updatedAt: now })
      .onConflictDoUpdate({ target: appState.deviceId, set: { data, updatedAt: now } });
    return json({ ok: true, updatedAt: now });
  }

  return bad("Method not allowed", 405);
};

export const config: Config = {
  path: "/api/state",
};
