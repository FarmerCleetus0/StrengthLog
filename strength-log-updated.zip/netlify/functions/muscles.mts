import type { Config } from "@netlify/functions";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic();
const MODEL = "claude-haiku-5-5";
const GROUPS = ["Chest", "Front delts", "Side delts", "Rear delts", "Traps", "Lats", "Lower back", "Biceps", "Triceps", "Brachialis", "Forearms", "Abs", "Obliques", "Quads", "Hamstrings", "Glutes", "Adductors", "Calves"] as const;
const json = (data: unknown, status = 200) => Response.json(data, { status });
const bad = (msg: string, status = 400) => json({ error: msg }, status);

const TOOL: Anthropic.Tool = {
  name: "report_muscles",
  description: "Report the muscle groups trained by each exercise.",
  input_schema: {
    type: "object",
    properties: {
      exercises: {
        type: "array",
        items: {
          type: "object",
          properties: {
            name: { type: "string", description: "Exercise name exactly as given" },
            primary: { type: "array", items: { type: "string", enum: [...GROUPS] }, description: "Main muscles doing the work (usually 1-2)" },
            secondary: { type: "array", items: { type: "string", enum: [...GROUPS] }, description: "Meaningful assisting muscles (0-3)" },
          },
          required: ["name", "primary", "secondary"],
        },
      },
    },
    required: ["exercises"],
  },
};

const SYSTEM = `You are a strength coach. For each gym exercise name, list which of these muscle groups it trains: ${GROUPS.join(", ")}.
"primary" = the muscles that are the main target. "secondary" = muscles that meaningfully assist (don't list stabilisers that barely work).
Lats covers the lats and mid-back (rhomboids/teres); Traps covers upper and mid traps; Lower back means the spinal erectors. Pick the specific delt head(s): presses mostly hit Front delts, lateral raises Side delts, reverse flyes/face pulls/rows Rear delts. Brachialis is hit hardest by hammer and reverse curls and assists most curls and pull-ups. Obliques cover rotation, side bends and assist most ab work.
If a name is unclear or not an exercise, give your best guess from the words; return empty arrays only if it clearly isn't a resistance or bodyweight exercise.
Always call report_muscles once with every exercise.`;

export default async (req: Request) => {
  if (req.method !== "POST") return bad("Not found", 404);
  const device = req.headers.get("x-device-id") ?? "";
  if (!/^[A-Za-z0-9-]{16,64}$/.test(device)) return bad("Missing device id", 401);
  const body = await req.json().catch(() => null);
  const names: string[] = Array.isArray(body?.names)
    ? [...new Set<string>(body.names.filter((n: unknown) => typeof n === "string").map((n: string) => n.trim().slice(0, 80)).filter(Boolean))].slice(0, 40)
    : [];
  if (!names.length) return bad("No exercises");

  try {
    const msg = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 2000,
      system: SYSTEM,
      tools: [TOOL],
      tool_choice: { type: "tool", name: "report_muscles" },
      messages: [{ role: "user", content: "Exercises:\n" + names.map((n) => "- " + n).join("\n") }],
    });
    const tool = msg.content.find((b) => b.type === "tool_use") as Anthropic.ToolUseBlock | undefined;
    const list = (tool?.input as any)?.exercises;
    if (!Array.isArray(list)) return bad("Couldn't work out the muscles. Try again.", 502);
    const valid = new Set<string>(GROUPS);
    const byLower = new Map(names.map((n) => [n.toLowerCase(), n]));
    const map: Record<string, Record<string, number>> = {};
    for (const ex of list) {
      const key = byLower.get(String(ex?.name ?? "").trim().toLowerCase());
      if (!key) continue;
      const m: Record<string, number> = {};
      for (const g of Array.isArray(ex.secondary) ? ex.secondary : []) if (valid.has(g)) m[g] = 0.5;
      for (const g of Array.isArray(ex.primary) ? ex.primary : []) if (valid.has(g)) m[g] = 1;
      map[key] = m;
    }
    return json({ map });
  } catch (e: any) {
    console.error("muscles failed", e?.status, e?.message);
    if (e?.status === 429) return bad("The AI is busy right now. Try again in a minute.", 429);
    return bad("Couldn't reach the AI. Try again.", 502);
  }
};

export const config: Config = { path: "/api/muscles" };
