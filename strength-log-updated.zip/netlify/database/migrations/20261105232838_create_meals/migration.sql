CREATE TABLE "meals" (
	"id" serial PRIMARY KEY,
	"device_id" text NOT NULL,
	"day" text NOT NULL,
	"name" text NOT NULL,
	"kind" text DEFAULT 'meal' NOT NULL,
	"kcal" integer DEFAULT 0 NOT NULL,
	"protein" real DEFAULT 0 NOT NULL,
	"carbs" real DEFAULT 0 NOT NULL,
	"fat" real DEFAULT 0 NOT NULL,
	"fiber" real,
	"items" jsonb,
	"note" text,
	"photo_key" text,
	"eaten_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "meals_device_day_idx" ON "meals" ("device_id","day");