CREATE TABLE "saved_labels" (
	"id" serial PRIMARY KEY,
	"device_id" text NOT NULL,
	"name" text NOT NULL,
	"serving" text,
	"kcal" integer DEFAULT 0 NOT NULL,
	"protein" real DEFAULT 0 NOT NULL,
	"carbs" real DEFAULT 0 NOT NULL,
	"fat" real DEFAULT 0 NOT NULL,
	"fiber" real,
	"photo_key" text,
	"uses" integer DEFAULT 1 NOT NULL,
	"used_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "meals" ADD COLUMN "photo_keys" jsonb;--> statement-breakpoint
CREATE INDEX "saved_labels_device_idx" ON "saved_labels" ("device_id","used_at");--> statement-breakpoint
INSERT INTO "saved_labels" ("device_id","name","kcal","protein","carbs","fat","fiber","photo_key","uses","used_at","created_at")
SELECT DISTINCT ON (m."device_id", lower(m."name"))
  m."device_id", m."name",
  COALESCE(CASE WHEN jsonb_array_length(m."items")=1 THEN round((m."items"->0->>'kcal')::numeric)::int END, m."kcal"),
  COALESCE(CASE WHEN jsonb_array_length(m."items")=1 THEN (m."items"->0->>'protein')::real END, m."protein"),
  COALESCE(CASE WHEN jsonb_array_length(m."items")=1 THEN (m."items"->0->>'carbs')::real END, m."carbs"),
  COALESCE(CASE WHEN jsonb_array_length(m."items")=1 THEN (m."items"->0->>'fat')::real END, m."fat"),
  m."fiber", m."photo_key",
  (SELECT count(*)::int FROM "meals" x WHERE x."device_id"=m."device_id" AND x."kind"='label' AND lower(x."name")=lower(m."name")),
  m."eaten_at", m."eaten_at"
FROM "meals" m
WHERE m."kind"='label' AND jsonb_typeof(COALESCE(m."items",'[]'::jsonb))='array'
ORDER BY m."device_id", lower(m."name"), m."eaten_at" DESC;
