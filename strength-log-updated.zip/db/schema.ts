import { pgTable, serial, text, timestamp, integer, real, jsonb, index } from "drizzle-orm/pg-core";

export const meals = pgTable(
  "meals",
  {
    id: serial().primaryKey(),
    deviceId: text("device_id").notNull(),
    day: text().notNull(), // local calendar day, YYYY-MM-DD
    name: text().notNull(),
    kind: text().notNull().default("meal"), // meal | label | manual
    kcal: integer().notNull().default(0),
    protein: real().notNull().default(0),
    carbs: real().notNull().default(0),
    fat: real().notNull().default(0),
    fiber: real(),
    items: jsonb().$type<{ name: string; amount?: string; kcal?: number; protein?: number; carbs?: number; fat?: number }[]>(),
    note: text(),
    photoKey: text("photo_key"),
    photoKeys: jsonb("photo_keys").$type<string[]>(),
    eatenAt: timestamp("eaten_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("meals_device_day_idx").on(t.deviceId, t.day)],
);

export const savedLabels = pgTable(
  "saved_labels",
  {
    id: serial().primaryKey(),
    deviceId: text("device_id").notNull(),
    name: text().notNull(),
    serving: text(),
    kcal: integer().notNull().default(0),
    protein: real().notNull().default(0),
    carbs: real().notNull().default(0),
    fat: real().notNull().default(0),
    fiber: real(),
    photoKey: text("photo_key"),
    uses: integer().notNull().default(1),
    usedAt: timestamp("used_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("saved_labels_device_idx").on(t.deviceId, t.usedAt)],
);

// Cloud copy of the on-device app data (workouts, routines, history, settings), one row per device / recovery code.
export const appState = pgTable("app_state", {
  deviceId: text("device_id").primaryKey(),
  data: jsonb().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
